import javax.swing.JPanel; 

class RedDot{
	
}